import discord
from discord.ext import commands
import os
from commands.tournament_commands import setup_tournament_commands

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user} (ID: {bot.user.id})')
    print('------')

@bot.event
async def on_guild_join(guild):
    os.makedirs(f'data/{guild.id}', exist_ok=True)

setup_tournament_commands(bot)

bot.run('YOUR_BOT_TOKEN')